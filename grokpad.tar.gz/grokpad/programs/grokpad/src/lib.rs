use anchor_lang::prelude::*;
use anchor_spl::token::{self, Mint, TokenAccount, Transfer, Token, MintTo, Burn};

pub mod state;
pub mod instructions;
pub mod errors;

use instructions::*;

/// GrokPad is an on‑chain program implementing a fair‑launch bonding
/// curve for meme tokens.  It mimics the mechanics of Pump.fun while
/// enforcing that all minted tokens end with the suffix `grok` in
/// their name and their mint address ends with `grok`.  The curve
/// pricing is defined in the `state::PriceState` struct and can be
/// updated in a future version if desired.
#[program]
pub mod grokpad {
    use super::*;

    /// Initializes a new launch by creating a new SPL token mint
    /// whose public key ends with the suffix `grok`.  The full supply
    /// of 1_000_000_000 tokens is minted, with 800_000_000 sent to
    /// the bonding curve vault for sale.  The remaining tokens stay
    /// in the program’s custody for future liquidity provisioning.
    pub fn initialize_launch(
        ctx: Context<InitializeLaunch>,
        name: String,
        symbol: String,
        price_state: state::PriceState,
    ) -> Result<()> {
        instructions::initialize_launch::handler(ctx, name, symbol, price_state)
    }

    /// Allows a buyer to purchase tokens from the bonding curve by
    /// sending SOL.  The price is determined by the current tranche
    /// and increases as more tokens are sold.  A protocol fee is
    /// deducted and sent to the treasury configured in
    /// `GlobalConfig`.
    pub fn buy_on_curve(ctx: Context<BuyOnCurve>, amount: u64) -> Result<()> {
        instructions::buy_on_curve::handler(ctx, amount)
    }

    /// Allows a holder to sell tokens back to the bonding curve in
    /// exchange for SOL.  Mirrors the buy logic but in reverse,
    /// computing the rebate according to the current tranche.  A
    /// protocol fee is deducted from the seller’s proceeds.
    pub fn sell_on_curve(ctx: Context<SellOnCurve>, amount: u64) -> Result<()> {
        instructions::sell_on_curve::handler(ctx, amount)
    }

    /// Graduates a launch once the bonding curve is filled or the
    /// configured market cap threshold has been reached.  This
    /// instruction creates a Raydium pool, deposits a portion of the
    /// collected SOL and tokens as liquidity, burns the LP tokens and
    /// flips trading to the AMM.  Only the admin may call this.
    pub fn graduate(ctx: Context<Graduate>) -> Result<()> {
        instructions::graduate::handler(ctx)
    }

    /// Updates metadata such as the token’s URI after launch.  The
    /// name must still end with `grok` to prevent misconfigured
    /// launches.
    pub fn set_metadata(
        ctx: Context<SetMetadata>,
        uri: String,
    ) -> Result<()> {
        instructions::set_metadata::handler(ctx, uri)
    }

    /// Administrative instruction to update global parameters such as
    /// fee rates, treasury address or graduation targets.
    pub fn admin(ctx: Context<Admin>, args: instructions::admin::AdminArgs) -> Result<()> {
        instructions::admin::handler(ctx, args)
    }
}