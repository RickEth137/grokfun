use anchor_lang::prelude::*;

/// Program specific error codes.  We define a handful of custom
/// errors to improve debugging.  Each error has a unique code and
/// descriptive message.
#[error_code]
pub enum GrokPadError {
    /// Returned when the name of a new token does not end with
    /// the required suffix `grok`.  This enforces the naming
    /// convention for all tokens launched on GrokPad.
    #[msg("Token name must end with 'grok'")]
    InvalidNameSuffix,

    /// Returned when attempting to buy or sell on a launch that has
    /// already graduated.  After graduation, all trading occurs on
    /// the AMM and the curve is closed.
    #[msg("Bonding curve closed; launch has already graduated")]
    CurveClosed,

    /// Returned when the program is paused by the admin.  Used to
    /// halt trading in emergency situations.
    #[msg("Program is currently paused")]
    ProgramPaused,

    /// Thrown when an overflow or underflow occurs in arithmetic.
    #[msg("Math error: overflow or underflow")] 
    MathError,
}