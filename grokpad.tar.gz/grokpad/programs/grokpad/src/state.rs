use anchor_lang::prelude::*;

/// `GlobalConfig` stores parameters that apply across all token
/// launches.  These values can be updated by the program admin via
/// the `admin` instruction.  They include fee rates (expressed in
/// basis points), the treasury address, the graduation target market
/// cap and the optional creator kickback percentage.
#[account]
#[derive(Default)]
pub struct GlobalConfig {
    /// Admin authority allowed to update global settings and pause the
    /// program.
    pub admin: Pubkey,
    /// Treasury account that receives protocol fees collected during
    /// curve trades and after graduation.
    pub treasury: Pubkey,
    /// Fee on bonding curve trades, in basis points (1/100 of a
    /// percent).  For example, 125 means a 1.25% fee.
    pub curve_fee_bps: u16,
    /// Fee on AMM trades post graduation, in basis points.  For
    /// example, 10 means a 0.10% fee.
    pub amm_fee_bps: u16,
    /// Portion of the protocol fee that goes back to the token
    /// creator, expressed in basis points.  A value of 0 means no
    /// kickback.
    pub creator_kickback_bps: u16,
    /// Target fully diluted market cap (in micro‑USD) at which the
    /// launch should graduate, e.g. 69_000_000_000 for $69k.  See
    /// `graduate` for more details.
    pub graduation_target_usd: u64,
    /// Flag to pause all trades.  When set, buy and sell
    /// instructions will fail.  Admin only.
    pub paused: bool,
}

/// `Launch` holds per‑token state.  Each token minted through the
/// launchpad has a corresponding `Launch` account that tracks how
/// many tokens have been sold, the pricing parameters and whether it
/// has graduated to an AMM pool.
#[account]
pub struct Launch {
    /// The creator of the token.  Receives a portion of fees if
    /// `creator_kickback_bps` is non‑zero.
    pub creator: Pubkey,
    /// The SPL mint representing the token.  Must end with `grok` in
    /// its base58 encoding.
    pub mint: Pubkey,
    /// SPL token account controlled by the program that holds the
    /// bonding curve inventory (800M tokens).  Buyers receive tokens
    /// from this account.
    pub curve_vault: Pubkey,
    /// Account that accumulates SOL during bonding curve purchases.
    pub sol_vault: Pubkey,
    /// How many tokens have been sold from the curve vault.
    pub sold: u64,
    /// The pricing parameters for the bonding curve.
    pub price_state: PriceState,
    /// Flag indicating whether the launch has been graduated.  When
    /// true, curve trades should no longer be allowed.
    pub graduated: bool,
    /// Optional metadata URI set after initialization.
    pub metadata_uri: String,
}

/// `PriceState` defines the step function used for calculating the
/// price on the bonding curve.  It is intentionally simple and
/// transparent: each tranche of `tranche_size` tokens sells at a
/// fixed price that increases by `step_bps` (basis points) over the
/// previous tranche.  The first tranche sells at `base_price_lamports`
/// lamports per token.
#[derive(AnchorSerialize, AnchorDeserialize, Clone, Default)]
pub struct PriceState {
    /// Number of tokens per tranche.  Typically 10_000_000 so that 80
    /// tranches cover 800M tokens.
    pub tranche_size: u64,
    /// Price of the first tranche in lamports per token.  Lamports are
    /// the smallest unit of SOL (1 SOL = 1_000_000_000 lamports).
    pub base_price_lamports: u64,
    /// Percentage increase per tranche, expressed in basis points.  A
    /// value of 250 means the price increases by 2.5% each tranche.
    pub step_bps: u16,
}