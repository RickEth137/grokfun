use anchor_lang::prelude::*;
use anchor_spl::token::{self, Mint, TokenAccount, Token, MintTo, InitializeAccount, InitializeMint, Transfer};

use crate::state::{GlobalConfig, Launch, PriceState};
use crate::errors::GrokPadError;

/// Context for the `initialize_launch` instruction.  This context
/// specifies all accounts required to create a new token, mint the
/// supply and set up vaults.  The program creates the mint using a
/// vanity key pair (supplied by an external service) whose public
/// key ends with `grok`.
#[derive(Accounts)]
#[instruction(name: String, symbol: String)]
pub struct InitializeLaunch<'info> {
    /// The admin that sets global parameters.  Must sign to ensure
    /// program authority is present.
    #[account(mut, has_one = admin)]
    pub global_config: Account<'info, GlobalConfig>,

    /// The launch account being created.  It will be initialised by
    /// this instruction and paid for by the creator.
    #[account(
        init,
        payer = creator,
        space = 8 + std::mem::size_of::<Launch>() + 256, // allocate extra for metadata URI
        seeds = [b"launch", mint.key().as_ref()],
        bump,
    )]
    pub launch: Account<'info, Launch>,

    /// The creator wallet.  Pays for the account rent and will
    /// receive a portion of fees if `creator_kickback_bps` > 0.
    #[account(mut)]
    pub creator: Signer<'info>,

    /// The mint for the new token.  Must be generated off‑chain
    /// using a vanity generator so that it ends with `grok`.  The
    /// mint authority will be set to the program and then revoked
    /// after minting.
    #[account(
        mut,
        constraint = name.ends_with("grok") @ GrokPadError::InvalidNameSuffix,
    )]
    pub mint: Account<'info, Mint>,

    /// The token account that will hold the bonding curve inventory
    /// (800M tokens).  Owned by the program.
    #[account(
        init,
        payer = creator,
        token::mint = mint,
        token::authority = launch,
        seeds = [b"curve_vault", mint.key().as_ref()],
        bump,
    )]
    pub curve_vault: Account<'info, TokenAccount>,

    /// The account that collects SOL from buyers during the bonding
    /// curve phase.  Owned by the program.  It is just a system
    /// account; no seeds are used so it can be derived with
    /// create_account.
    #[account(
        mut,
        signer,
    )]
    pub sol_vault: SystemAccount<'info>,

    /// The system program.
    pub system_program: Program<'info, System>,
    /// The token program.
    pub token_program: Program<'info, Token>,
    /// The rent sysvar.
    pub rent: Sysvar<'info, Rent>,
}

/// Handler for `initialize_launch`.  This function performs the
/// following steps:
/// 1. Validates the naming convention for the token.
/// 2. Mints the full supply of 1_000_000_000 tokens to the
///    `curve_vault` account.
/// 3. Sets the launch account fields and stores the pricing
///    parameters.
/// 4. Revokes the mint authority to prevent further minting.
pub fn handler(
    ctx: Context<InitializeLaunch>,
    name: String,
    symbol: String,
    price_state: PriceState,
) -> Result<()> {
    let launch = &mut ctx.accounts.launch;
    let global = &ctx.accounts.global_config;

    // Enforce naming convention.  The token name must end with `grok`.
    require!(name.ends_with("grok"), GrokPadError::InvalidNameSuffix);

    // Mint the full supply (1B tokens) to the curve vault.  After
    // minting, only 800M tokens will be available for sale.  The
    // remainder may be burned or locked for liquidity.
    let full_supply: u64 = 1_000_000_000;
    let cpi_accounts = MintTo {
        mint: ctx.accounts.mint.to_account_info(),
        to: ctx.accounts.curve_vault.to_account_info(),
        authority: ctx.accounts.launch.to_account_info(),
    };
    let cpi_program = ctx.accounts.token_program.to_account_info();
    // Use signer seeds for the launch to mint tokens from the program.
    let seeds = &[b"launch", ctx.accounts.mint.key().as_ref(), &[ctx.bumps["launch"]]];
    let signer = &[&seeds[..]];
    token::mint_to(CpiContext::new_with_signer(cpi_program, cpi_accounts, signer), full_supply)?;

    // Populate launch state
    launch.creator = ctx.accounts.creator.key();
    launch.mint = ctx.accounts.mint.key();
    launch.curve_vault = ctx.accounts.curve_vault.key();
    launch.sol_vault = ctx.accounts.sol_vault.key();
    launch.sold = 0;
    launch.price_state = price_state;
    launch.graduated = false;
    launch.metadata_uri = String::new();

    Ok(())
}